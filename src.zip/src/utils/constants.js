// export const BASE_URL = 'https://api.diminenn-me.students.nomoredomains.rocks';
// export const MOVIES_API_URL = 'https://api.nomoreparties.co/beatfilm-movies';
// export const MOVIES_IMAGE_URL = 'https://api.nomoreparties.co';
